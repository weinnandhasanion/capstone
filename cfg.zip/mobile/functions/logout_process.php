<?php 
require "./connect.php";
session_start();
unset($_SESSION["member_id"]);
?>